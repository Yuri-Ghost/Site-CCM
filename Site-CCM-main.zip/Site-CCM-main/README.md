# Site-CCM
Aqui haverá o site do Colégio Cívico Militar República Oriental do Uruguai
o bagulho é doido memo, azideia
